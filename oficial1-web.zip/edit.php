<!doctype html>
<html>
    <head>
         <!-- 
    * <instituição: União Metropolitana de Educação e Cultura(UNIME)>
    * <curso: Bacharelado em sistemas da informação>
    * <disciplina: programação web II>
    * <Professor: Pablo Ricardo Roxo Silva>
    * <Aluno: Samorano Jesus da Silva>
     -->
        <title>Locadora De DVD</title>
        <link rel="stylesheet" href="css/index.css">
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Lista de filmes</h1>
        <div>
            <?php
                $conexao = new mysqli('localhost', 'root', '', 'locadora');
                
                if($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if(empty($_POST['nome'])) {
                        echo 'Nome não informado';
                    } else if(empty($_POST['genero'])) {
                        echo 'Genero não informado';
                    }else if(empty($_POST['diretor'])) {
                        echo 'Diretor não informado';
                    }else if(empty($_POST['locacao'])) {
                        echo 'Locação não informada';
                    } else {
                        $query = "UPDATE filme
                                    SET
                                        nome = '". addslashes($_POST['nome']) ."',
                                        genero = '". addslashes($_POST['genero']) ."',
                                        diretor = '". addslashes($_POST['diretor']) ."',
                                        locacao = '". $_POST['locacao'] ."'
                                        ". (!empty($_POST['devolucao']) ? ", devolucao = '" . $_POST['devolucao'] . "'" : '') ."
                                    WHERE id = " . $_POST['id'] . ";";
                        // echo $query;
                        $conexao->query($query);
                        header('Location: index.php');
                    }
                }

                $query = "SELECT * FROM filme WHERE id = " . $_GET['id'] . ";";
                $filme = $conexao->query($query);
                $filme = $filme->fetch_assoc();

                adaptarDataHora($filme['locacao']);

                function adaptarDataHora($dataHora) {
                    if($dataHora) {
                        $dataHora = str_replace(' ', 'T', $dataHora);
                        $dataHora = substr($dataHora, 0, 16);
                        return $dataHora;
                    }
                }
            ?>
            <form method="POST">
                <div>
                    Nome: <input name="nome" type="text" value="<?= $filme['nome'] ?>" />
                </div>
                <div>
                    Genero: <input name="genero" type="text" value="<?= $filme['genero'] ?>" />
                </div>
                <div>
                    Diretor: <input name="diretor" type="text" value="<?= $filme['diretor'] ?>" />
                </div>
                <div>
                    Locação: <input name="locacao" type="datetime-local" value="<?= adaptarDataHora($filme['locacao']) ?>" />
                </div>
                <div>
                    Devolução (opcional): <input name="devolucao" type="datetime-local" value="<?= adaptarDataHora($filme['devolucao']) ?>" />
                </div>
                <div>
                    <input type="hidden" name="id" value="<?= $_GET['id'] ?>" />
                    <input type="submit" />
                </div>
            </form>
        </div>
    </body>
</html>