<!doctype html>
<html>
    <head>
          <!-- 
    * <instituição: União Metropolitana de Educação e Cultura(UNIME)>
    * <curso: Bacharelado em sistemas da informação>
    * <disciplina: programação web II>
    * <Professor: Pablo Ricardo Roxo Silva>
    * <Aluno: Samorano Jesus da Silva>
     -->
        <title>Locadora De DVD</title>
        <link rel="stylesheet" href="css/index.css">
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Lista de filmes</h1>
        <div id="cadastro">
            <h3><a href="add.php" >Cadastrar filme</a></h3>
        </div>
        <div >
            
            <table border="10px"  cellpadding="30px" cellspacing="0">
                <tr>
                    <th>Nome</th>
                    <th>Gênero</th>
                    <th>Diretor</th>
                    <th>Locação</th>
                    <th>Devolução</th>
                    <th>Opções</th>
                </tr>

                <?php
                    $conexao = new mysqli('localhost', 'root', '', 'locadora');
                    
                    if(!empty($_GET['id'])) {
                        $query = "DELETE FROM filme WHERE id = " . $_GET['id'] . ";";
                        $conexao->query($query);
                    }

                    $query = "SELECT * FROM filme;";
                    $lista = $conexao->query($query);

                    while($dvd = $lista->fetch_assoc()) {
                        echo '
                            <tr>
                                <td>' . $dvd['nome'] . '</td>
                                <td>' . $dvd['genero'] . '</td>
                                <td>' . $dvd['diretor'] . '</td>
                                <td>' . formatarDataHora($dvd['locacao']) . '</td>
                                <td>' . formatarDataHora($dvd['devolucao']) . '</td>
                                <td>
                                    <a href="edit.php?id=' . $dvd['id'] . '">Editar</a>
                                    <a href="#" onclick="excluir(' . $dvd['id'] . ')">Excluir</a>
                                </td>
                            </tr>
                        ';
                    }

                    function formatarDataHora($dataHora) {
                        if($dataHora) {
                            $dataHora = DateTime::createFromFormat('Y-m-d H:i:s', $dataHora);
                            return $dataHora->format('d/m/Y') . ' às ' . $dataHora->format('H:i:s');
                        }
                    }
                ?>
            </table>
        </div>
        <script type="text/javascript">
            function excluir(id) {
                if(confirm("Deseja realmente apagar o filme?")) {
                    window.location = '?id=' + id;
                }
            }
        </script>
    </body>
</html>