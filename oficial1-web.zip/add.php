<!doctype html>
<html>
    <head>
         <!-- 
    * <instituição: União Metropolitana de Educação e Cultura(UNIME)>
    * <curso: Bacharelado em sistemas da informação>
    * <disciplina: programação web II>
    * <Professor: Pablo Ricardo Roxo Silva>
    * <Aluno: Samorano Jesus da Silva>
     -->
        <title>Locadora De DVD</title>
        <link rel="stylesheet" href="css/index.css">
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Lista de filmes</h1>
        <div>
            <?php
                if($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if(empty($_POST['nome'])) {
                        echo 'Nome não informado';
                    } else if(empty($_POST['genero'])) {
                        echo 'Genero não informada';
                    }else if(empty($_POST['diretor'])) {
                        echo 'diretor não informada';
                    } else if(empty($_POST['locacao'])) {
                        echo 'Locação não informada';
                    } else {
                        $conexao = new mysqli('localhost', 'root', '', 'locadora');
                        $query = "INSERT INTO filme
                                        (
                                            nome,
                                            genero,
                                            diretor,
                                            locacao
                                            ". (!empty($_POST['devolucao']) ? ', devolucao' : '') ."
                                        )
                                    VALUES
                                        (
                                            '". addslashes($_POST['nome']) ."',
                                            '". addslashes($_POST['genero']) ."',
                                            '". addslashes($_POST['diretor']) ."',
                                            '". $_POST['locacao'] ."'
                                            ". (!empty($_POST['devolucao']) ? ", '". $_POST['devolucao'] ."'" : '') ."
                                        );";
                        //echo $query;
                         $conexao->query($query);
                        header('Location: index.php'); 
                    }
                }
            ?>
            <form method="POST">
                <div>
                    Nome: <input name="nome" type="text" />
                </div>
                <div>
                    Genero: <input name="genero" type="text" />
                </div>
                <div>
                    Diretor: <input name="diretor" type="text" />
                </div>
                <div>
                    Locação: <input name="locacao" type="datetime-local" />
                </div>
                <div>
                    Devolução (opcional): <input name="devolucao" type="datetime-local" />
                </div>
                <div>
                    <input id="button" type="submit" />
                </div>
            </form>
        </div>
    </body>
</html>